﻿using System;
using System.Collections.Generic;

namespace CoreApi.Model
{
    public partial class People
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
    }
}
